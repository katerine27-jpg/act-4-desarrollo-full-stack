const express = require("express");
const mongoose = require("mongoose");
const Product = require("../models/Product");

const auth = require("../middleware/auth");
const requireRole = require("../middleware/requireRole");

const router = express.Router();

/*ADMIN: CRUD COMPLETO */

// CREATE
router.post("/", auth, requireRole("admin"), async (req, res) => {
  try {
    const product = await Product.create(req.body);
    return res.status(201).json(product);
  } catch (e) {
    return res.status(500).json({ message: "Error creando producto", error: e.message });
  }
});

// READ ALL
router.get("/", auth, requireRole("admin"), async (req, res) => {
  try {
    const products = await Product.find();
    return res.status(200).json(products);
  } catch (e) {
    return res.status(500).json({ message: "Error obteniendo productos", error: e.message });
  }
});

// READ ONE
router.get("/:id", auth, requireRole("admin"), async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id))
      return res.status(400).json({ message: "ID inválido" });

    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: "Producto no encontrado" });

    return res.status(200).json(product);
  } catch (e) {
    return res.status(500).json({ message: "Error obteniendo producto", error: e.message });
  }
});

// UPDATE ANY FIELD
router.put("/:id", auth, requireRole("admin"), async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id))
      return res.status(400).json({ message: "ID inválido" });

    const product = await Product.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!product) return res.status(404).json({ message: "Producto no encontrado" });

    return res.status(200).json(product);
  } catch (e) {
    return res.status(500).json({ message: "Error actualizando producto", error: e.message });
  }
});

// DELETE
router.delete("/:id", auth, requireRole("admin"), async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id))
      return res.status(400).json({ message: "ID inválido" });

    const deleted = await Product.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Producto no encontrado" });

    return res.status(204).send();
  } catch (e) {
    return res.status(500).json({ message: "Error eliminando producto", error: e.message });
  }
});


/* =========================
   USER: SOLO MODIFICAR STOCK
   ========================= */

router.patch("/:id/stock", auth, requireRole("user"), async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id))
      return res.status(400).json({ message: "ID inválido" });

    const { stock } = req.body;
    if (stock === undefined)
      return res.status(400).json({ message: "Debes enviar el campo stock" });

    // Impedir modificar otros campos
    if (Object.keys(req.body).length > 1)
      return res.status(403).json({ message: "Solo puedes modificar el stock" });

    const product = await Product.findByIdAndUpdate(
      req.params.id,
      { stock },
      { new: true, runValidators: true }
    );

    if (!product) return res.status(404).json({ message: "Producto no encontrado" });

    return res.status(200).json(product);
  } catch (e) {
    return res.status(500).json({ message: "Error actualizando stock", error: e.message });
  }
});

module.exports = router;
